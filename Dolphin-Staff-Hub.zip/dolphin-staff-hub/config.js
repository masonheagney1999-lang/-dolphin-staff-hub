// Replace these two values with your Supabase project's URL and publishable/anon key.
// NEVER put the service_role or secret key in this file.
window.DOLPHIN_CONFIG = {
  supabaseUrl: 'YOUR_SUPABASE_PROJECT_URL',
  supabaseAnonKey: 'YOUR_SUPABASE_PUBLISHABLE_KEY',
  hoursFormUrl: 'https://docs.google.com/forms/d/e/1FAIpQLSfFlbbPuxPjYGL0QHH3nfMaciYMpqUqoA1cshMDTeRDDUbpRg/viewform',
  fuelFormUrl: 'https://docs.google.com/forms/d/e/1FAIpQLSefGuXPXOA_S45O9PGAl6aQuAp2giYRxz7ujMi4d9FW79I9Bg/viewform'
};
