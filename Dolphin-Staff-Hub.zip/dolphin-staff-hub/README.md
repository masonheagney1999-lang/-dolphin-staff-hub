# Dolphin Travel Staff Hub

A mobile-friendly staff portal with email/password sign-in, private document storage, driver download access, office-only uploads/deletion, a noticeboard and links to the existing driver hours and fuel Google Forms.

## Set up

1. Create a Supabase project at https://supabase.com and open **SQL Editor**. Run the complete `setup.sql` script once.
2. In Supabase **Authentication > Providers**, enable email/password sign-in. Disable public sign-ups if available; create staff accounts yourself using **Authentication > Users > Add user**. Make sure users have a confirmed email.
3. In **Project Settings > API** (or **Connect**), copy the project URL and the **publishable/anon** key into `config.js`. Never put a secret or service-role key in a website.
4. In SQL Editor, create each staff profile, substituting the user's actual auth UUID:

   `insert into public.staff_profiles(id,role) values ('USER_UUID_HERE','driver');`

   For your account and approved office staff, use `office` instead of `driver`. **Do not let users choose their own roles.**
5. Upload `index.html` and `config.js` to your HTTPS website hosting (e.g. Netlify, GitHub Pages or your own host). You can configure `staff.dolphin-travel.co.uk` later using your domain's DNS settings.
6. Test with one office account and one driver account: only office should see upload and notice posting controls. Confirm drivers can download but cannot upload/delete.
7. Check the existing Google Forms sharing permissions and destination spreadsheets. The hub only links to those forms; it does not change their permissions or collect form responses itself.

## Security and limitations

- File storage is a **private** Supabase bucket, with row-level security and short-lived download URLs.
- Users must have an authentication account **and** a `staff_profiles` record to access documents. Only office profiles can upload or delete.
- Admin role assignment happens in Supabase, never in the browser. Do not give staff access to your Supabase admin dashboard.
- Supabase hosting/storage may incur charges as usage grows. Review plan limits before inviting the team.
- For production, configure MFA for office staff where supported, backups, a retention policy, and a privacy notice. Avoid uploading highly sensitive personnel documents until appropriate controls are in place.
- This is a deployable starter, **not a live website**. You must configure Supabase and hosting.
- File size limit: 15 MB. Supported: PDF, Word, Excel, PNG, JPG, TXT.
