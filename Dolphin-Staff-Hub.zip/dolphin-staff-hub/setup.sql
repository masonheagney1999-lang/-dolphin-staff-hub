-- Run in Supabase SQL Editor. Only authenticated accounts can use the hub.
create table public.staff_profiles (id uuid primary key references auth.users(id) on delete cascade, role text not null default 'driver' check (role in ('driver','office')));
create table public.staff_files (id uuid primary key default gen_random_uuid(), name text not null, category text not null default 'General', storage_path text not null unique, uploaded_by uuid not null references auth.users(id), created_at timestamptz not null default now());
create table public.staff_notices (id uuid primary key default gen_random_uuid(), message text not null check(char_length(message) between 1 and 1500), posted_by uuid not null references auth.users(id), created_at timestamptz not null default now());
create or replace function public.is_office() returns boolean language sql stable security definer set search_path='' as $$select exists(select 1 from public.staff_profiles where id=(select auth.uid()) and role='office')$$;
revoke all on function public.is_office() from public; grant execute on function public.is_office() to authenticated;
alter table public.staff_profiles enable row level security;
alter table public.staff_files enable row level security;
alter table public.staff_notices enable row level security;
create policy "read own profile" on public.staff_profiles for select to authenticated using (id=(select auth.uid()));
create policy "staff read files" on public.staff_files for select to authenticated using (exists(select 1 from public.staff_profiles where id=(select auth.uid())));
create policy "office insert files" on public.staff_files for insert to authenticated with check (public.is_office() and uploaded_by=(select auth.uid()));
create policy "office delete files" on public.staff_files for delete to authenticated using (public.is_office());
create policy "staff read notices" on public.staff_notices for select to authenticated using (exists(select 1 from public.staff_profiles where id=(select auth.uid())));
create policy "office insert notices" on public.staff_notices for insert to authenticated with check (public.is_office() and posted_by=(select auth.uid()));
create policy "office delete notices" on public.staff_notices for delete to authenticated using (public.is_office());
insert into storage.buckets (id,name,public,file_size_limit,allowed_mime_types) values ('staff-documents','staff-documents',false,15728640,array['application/pdf','application/msword','application/vnd.openxmlformats-officedocument.wordprocessingml.document','application/vnd.ms-excel','application/vnd.openxmlformats-officedocument.spreadsheetml.sheet','image/png','image/jpeg','text/plain']) on conflict(id) do nothing;
create policy "staff download storage" on storage.objects for select to authenticated using(bucket_id='staff-documents' and exists(select 1 from public.staff_profiles where id=(select auth.uid())));
create policy "office upload storage" on storage.objects for insert to authenticated with check(bucket_id='staff-documents' and public.is_office());
create policy "office delete storage" on storage.objects for delete to authenticated using(bucket_id='staff-documents' and public.is_office());
-- No policy permits drivers to upload, modify or delete anything.
